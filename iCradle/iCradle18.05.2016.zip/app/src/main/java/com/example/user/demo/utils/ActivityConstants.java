package com.example.user.demo.utils;

/**
 * Created by User on 03.02.2016.
 */
public class ActivityConstants {

    public static int DATE_DETAIL_ITEM = 10;
}
